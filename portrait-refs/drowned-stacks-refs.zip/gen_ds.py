import urllib.parse, urllib.request, os, time, sys

OUT = "/tmp/ds-portraits"
STYLE = ("painterly fantasy illustration, drowned library-city, grubby salvage-punk fantasy, "
         "not photorealistic, not anime, moody chiaroscuro, warm oil-lamp amber against cold "
         "ink-black water, wet paper and waterlogged leather textures, verdigris and sepia "
         "palette, lantern-smoke, loose confident brushwork, ink-wash shadows, in the spirit of "
         "Ian McQue and Craig Mullins and Dave McKean and Gustave Dore engraving, atmospheric, "
         "highly detailed concept art")

JOBS = [
    ("01_drypoint", 1216, 832,
     "wide establishing view of Drypoint, a frontier salvage-town built in the dry upper stacks "
     "of a drowned library: crooked timber scaffolding and rope-lashed walkways threaded between "
     "colossal book-shelving rising like canyon walls, rain-eaves dripping, oil lanterns burning "
     "warm in a hundred windows, black ink-thick floodwater below reflecting the lamps, salvaged "
     "books stacked as building material, drying-lines strung with damp pages, overcast drizzle, "
     "human-small figures on the gangways, cathedral scale, cinematic wide shot"),
    ("02_kest_ferryman", 832, 1216,
     "character portrait of an old ferryman, weathered and rope-built, sinewy and knotted and "
     "lean, decades on the water in his face, standing at the stern of a narrow flat-bottomed "
     "skiff with both hands on a long poling-staff, working a flooded shelf-canyon of black "
     "water walled by drowned bookcases, oilskin coat slick with damp, a guttering lantern hung "
     "at the prow, a worn dog-eared penny-dreadful in his coat pocket, warm but guarded "
     "expression, lamplight catching wet rope and wet stone, half-length three-quarter view"),
    ("03_crew_tave_cut_pott", 1216, 832,
     "group portrait of a three-person salvage-diving crew gathered at a lamplit tavern landing "
     "with a drowned shelf-canyon behind them: on the left a hatchet-faced hard laconic older "
     "diver named Tave with a coil of dive-line over one shoulder; center a round-built powerful "
     "dry-smiling pump-and-line hand named Cut resting hands on a hand-cranked dive-pump; on the "
     "right a wiry thirteen-year-old spotter named Pott mid-sentence in a too-big salvaged coat "
     "perched on a crate, eager, grubby practical salvage gear, patched oilskins, essence-lamps "
     "burning amber, camaraderie worn as gruffness, ensemble portrait"),
]

def fetch(name, w, h, prompt, seed):
    full = f"{prompt}, {STYLE}"
    url = ("https://image.pollinations.ai/prompt/" + urllib.parse.quote(full) +
           f"?width={w}&height={h}&model=flux&nologo=true&seed={seed}")
    path = os.path.join(OUT, name + ".jpg")
    for attempt in range(1, 4):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "baton-ref/1.0"})
            with urllib.request.urlopen(req, timeout=120) as r:
                data = r.read()
            if len(data) < 20000:
                raise ValueError(f"suspiciously small ({len(data)} bytes)")
            with open(path, "wb") as f:
                f.write(data)
            print(f"  OK  {name}.jpg  {len(data)//1024} KB  ({w}x{h}, seed {seed})")
            return True
        except Exception as e:
            print(f"  .. {name} attempt {attempt} failed: {e}")
            time.sleep(4)
    print(f"  XX {name} FAILED after 3 attempts")
    return False

print("Generating Drowned Stacks reference images via Pollinations (Flux)...")
ok = 0
for i, (name, w, h, prompt) in enumerate(JOBS):
    if fetch(name, w, h, prompt, seed=4200 + i):
        ok += 1
print(f"\n{ok}/{len(JOBS)} generated -> {OUT}")
sys.exit(0 if ok == len(JOBS) else 1)
