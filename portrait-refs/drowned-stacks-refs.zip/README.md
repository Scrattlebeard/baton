# Drowned Stacks — reference images (Pollinations / Flux)

Player-safe concept references for the Baton story *The Drowned Stacks*.
Generated 2026-07-07 via the **Pollinations** free API (no key), model **Flux**.
No `[SEALED]` content encoded — appearances the player has already seen only.

## House style (shared spine)
painterly fantasy illustration, drowned library-city, grubby salvage-punk fantasy,
not photorealistic, not anime, moody chiaroscuro, warm oil-lamp amber against cold
ink-black water, wet paper and waterlogged leather, verdigris and sepia palette,
lantern-smoke, loose brushwork, ink-wash shadows, in the spirit of Ian McQue,
Craig Mullins, Dave McKean, Gustave Doré. atmospheric, highly detailed concept art.

## Images
| file | subject | size | seed |
|---|---|---|---|
| 01_drypoint.jpg | Drypoint — establishing shot of the salvage-town | 1216x832 | 4200 |
| 02_kest_ferryman.jpg | Marginal Kest, the ferryman, poling the Narrows | 832x1216 | 4201 |
| 03_crew_tave_cut_pott.jpg | Westranks dive-crew: Tave, Cut & Pott (note: Flux added a 4th figure) | 1216x832 | 4202 |

Regenerate: `python3 gen_ds.py` (script included). Seeds are fixed for reproducibility.
