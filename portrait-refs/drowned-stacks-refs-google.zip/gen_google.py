#!/usr/bin/env python3
"""Generate Drowned Stacks reference images via Google Gemini image API
(Nano Banana 2 lite = gemini-3.1-flash-lite-image). Needs GOOGLE_API_KEY in env."""
import os, json, base64, time, urllib.request, urllib.error
KEY=os.environ["GOOGLE_API_KEY"]; MODEL="gemini-3.1-flash-lite-image"; OUT="."
STYLE=("painterly fantasy illustration, drowned library-city, grubby salvage-punk fantasy, "
       "not photorealistic, not anime, moody chiaroscuro, warm oil-lamp amber against cold "
       "ink-black water, wet paper and waterlogged leather, verdigris and sepia palette, "
       "lantern-smoke, loose confident brushwork, ink-wash shadows, in the spirit of Ian McQue, "
       "Craig Mullins, Dave McKean and Gustave Dore, atmospheric, highly detailed concept art")
JOBS=[
 ("01_drypoint","16:9","wide establishing view of Drypoint, a frontier salvage-town in the dry "
  "upper stacks of a drowned library: crooked timber scaffolding and rope-lashed walkways between "
  "colossal book-shelving rising like canyon walls, oil lanterns in a hundred windows, black "
  "ink-thick floodwater below reflecting the lamps, salvaged books stacked as building material, "
  "overcast drizzle, human-small figures on the gangways, cathedral scale"),
 ("02_kest_ferryman","3:4","character portrait of an old ferryman, weathered and rope-built, sinewy "
  "and lean, poling a narrow skiff through a flooded shelf-canyon of black water walled by drowned "
  "bookcases, oilskin coat, guttering lantern at the prow, warm but guarded expression"),
 ("03_crew_tave_cut_pott","16:9","group portrait of exactly three salvage divers at a lamplit "
  "tavern landing, drowned shelf-canyon behind: left a hatchet-faced hard laconic older diver with "
  "a coil of dive-line; center a round-built powerful dry-smiling pump hand at a hand-cranked "
  "dive-pump; right a wiry thirteen-year-old spotter in a too-big coat, eager, mid-sentence"),
]
def gen(name,ar,prompt):
    url=f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent?key={KEY}"
    body={"contents":[{"parts":[{"text":f"{prompt}, {STYLE}"}]}],
          "generationConfig":{"responseModalities":["IMAGE"],"imageConfig":{"aspectRatio":ar}}}
    req=urllib.request.Request(url,data=json.dumps(body).encode(),
        headers={"Content-Type":"application/json"},method="POST")
    try:
        with urllib.request.urlopen(req,timeout=120) as r: d=json.loads(r.read())
    except urllib.error.HTTPError as e:
        print(f"  {name}: HTTP {e.code} {e.read().decode()[:200]}"); return False
    for c in d.get("candidates",[]):
        for p in c.get("content",{}).get("parts",[]):
            if "inlineData" in p:
                open(f"{OUT}/{name}.png","wb").write(base64.b64decode(p["inlineData"]["data"]))
                print(f"  {name}: OK ({ar})"); return True
    return False
for n,a,p in JOBS: gen(n,a,p); time.sleep(2)
