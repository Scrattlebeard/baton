# Drowned Stacks — reference images (Google / Nano Banana 2 lite)

Player-safe concept references for the Baton story *The Drowned Stacks*.
Generated 2026-07-07 via the **Google Gemini image API**, model
**`gemini-3.1-flash-lite-image`** ("Nano Banana 2 lite"). Aspect ratio set via
`generationConfig.imageConfig.aspectRatio`. No `[SEALED]` content encoded.

Best-of-three engines tested (Pollinations/Flux, Leonardo, Google): this set
won on coherence — clean faces/hands, correct 3-person crew count, in-world
signage, real depth. Shared house style spine is baked into every prompt.

| file | subject | aspect |
|---|---|---|
| 01_drypoint.png | Drypoint — establishing shot | 16:9 |
| 02_kest_ferryman.png | Marginal Kest, the ferryman | 3:4 |
| 03_crew_tave_cut_pott.png | Westranks dive-crew (correct 3-count) | 16:9 |

Regenerate: `GOOGLE_API_KEY=… python3 gen_google.py`.
